var x = document.getElementById("video");

function playVideo(){
    x.play();
}
function pauseVideo(){
    x.pause();
}